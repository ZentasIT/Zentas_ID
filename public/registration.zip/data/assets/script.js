function loadUserHead(){
    document.getElementById("userName").textContent = `${userName}    ${userSurname}`
    document.getElementById("userName2").textContent = `${userName}    ${userSurname}`
    document.getElementById("date").textContent = `${date}`
    document.getElementById("phone").textContent = `${phone}`
}