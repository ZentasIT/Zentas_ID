require('dotenv').config()
const express = require('express');
const bodyParser = require('body-parser');
const  cors = require('cors');
const cookieParser = require('cookie-parser');
const router = require('./router/index')
const path = require("path");

const ID = require('./content/id-page')
const fs = require("fs");

const PORT = process.env.PORT
const app = express()

app.use(bodyParser.json());
app.use(express.json())
app.use(cookieParser())
app.use(cors())
app.use('/api', router)
app.use(ID)
app.use(express.static(path.join(__dirname,'..','public')));



const start = async () => {
    try{
        if ("SOCKET" in process.env) {
            const socket = process.env.SOCKET;
            if (fs.existsSync(socket)) {
                fs.unlinkSync(socket);
            }
            app.listen(socket, () => {
                fs.chmodSync(socket, 0660);
                console.log(`Сервер запещен! Дата: ${new Date()}`);
                console.log(`Listening :${socket}`);
            });
        } else if ("PORT" in process.env) {
            app.listen(PORT, () => {
                console.log(`Сервер запещен! Дата: ${new Date()}`);

                console.log(`Listening http:/:${PORT}/`);
            });

        } else {
            app.listen(5001, function(){
                console.log(`Сервер запещен! Дата: ${new Date()}`);
                console.log('listening on *:5001');
            });
        }
        // await mongoose.connect(process.env.DB_URL, {
        //     useNewUrlParser: true,
        //     useUnifiedTopology: true,
        // })
        // app.listen(PORT, ()=> console.log(`Server is running on port ${PORT}`))
    }catch(e){
        console.log(e)
    }
}
start()