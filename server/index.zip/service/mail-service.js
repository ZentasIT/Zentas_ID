class MailService {
    async sendActivationMail(to, link) {}

}
module.exports = new MailService();